// firebaseAdmin.js
const admin = require('firebase-admin');
const serviceAccount = require('./saganovel-e075a-firebase-adminsdk-fbsvc-4857470195.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://saganovel-e075a-default-rtdb.asia-southeast1.firebasedatabase.app"
});

const db = admin.database();

module.exports = { db };

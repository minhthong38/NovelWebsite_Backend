const mongoose = require("mongoose");

const ChapterContentSchema = new mongoose.Schema({
  idChapter: { type: mongoose.Schema.Types.ObjectId, ref: "Chapter", required: true }, // Liên kết với tiểu thuyết
  content: { type: String, required: true }, // Nội dung chương
}, { timestamps: true, collection: "ChapterContents" });

module.exports = mongoose.model("ChapterContent", ChapterContentSchema);

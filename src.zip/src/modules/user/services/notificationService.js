const Notification = require('../../../models/users/notificationModel');
const User = require('../../../models/users/userModel');
const { db } = require('../../../config/firebaseAdmin');

// Hàm riêng để đẩy thông báo lên Firebase Realtime Database
const pushNotificationToFirebase = async (userId, notification) => {
  const ref = db.ref(`notifications/${userId}/${notification._id}`);
  await ref.set({
    id: notification._id.toString(),
    title: notification.title,
    description: notification.description,
    link: notification.link,
    type: notification.type,
    isRead: false,
    createdAt: new Date().toISOString()
  });
};

// Tạo thông báo
const createNotification = async ({ userId, title, description, link, type }) => {
  try {
    const userExists = await User.findById(userId);
    if (!userExists) throw new Error("Người dùng không tồn tại.");

    const notification = new Notification({
      userId,
      title,
      description,
      link,
      type,
    });

    await notification.save();

    // 🔥 Đẩy real-time thông báo lên Firebase
    await pushNotificationToFirebase(userId, notification);

    return notification;
  } catch (error) {
    console.error("Lỗi khi tạo thông báo:", error);
    throw new Error('Lỗi khi tạo thông báo: ' + error.message);
  }
};

// Lấy tất cả thông báo của người dùng
const getNotificationsByUser = async (userId) => {
  try {
    const notifications = await Notification.find({ userId }).sort({ createdAt: -1 });
    return notifications;
  } catch (error) {
    throw new Error('Lỗi khi lấy thông báo');
  }
};

// Đánh dấu thông báo là đã đọc
const markAsRead = async (notificationId) => {
  try {
    const updatedNotification = await Notification.findByIdAndUpdate(
      notificationId,
      { isRead: true },
      { new: true }
    );
    return updatedNotification;
  } catch (error) {
    throw new Error('Lỗi khi đánh dấu thông báo là đã đọc');
  }
};

const deleteNotification = async (notificationId) => {
    try {
      await Notification.findByIdAndDelete(notificationId);
    } catch (error) {
      throw new Error('Lỗi khi xóa thông báo');
    }
  };

// Xóa thông báo theo ID người dùng
const deleteAllNotificationsByUser = async (userId) => {
  try {
    await Notification.deleteMany({ userId });
  } catch (error) {
    throw new Error('Lỗi khi xóa thông báo theo người dùng');
  }
};

module.exports = {
  createNotification,
  getNotificationsByUser,
  markAsRead,
  deleteNotification,
  deleteAllNotificationsByUser
};

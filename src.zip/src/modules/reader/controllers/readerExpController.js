const readerExpService = require("../services/readerExpService");

//lấy tất cả Reader Exp
const getAllReaderExp = async (req, res) => {
    try {
        const data = await readerExpService.getAllReaderExp();
        res.status(200).json({ success: true, data });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

//lấy Reader Exp theo ID
const getReaderExpById = async (req, res) => {
    const { id } = req.params;
    const data = await ReaderExp.findById(id).populate("idLevel"); // Lấy kèm thông tin cấp độ
    if (!data) return res.status(404).json({ success: false, message: "Không tìm thấy ReaderExp" });
  
    res.status(200).json({ success: true, data });
  };
  

//Cộng EXP khi đọc chapter (mặc định +10)
const addExpToReader = async (req, res) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ message: "Thiếu userId" });
    }

    const result = await readerExpService.addExpWhenReadChapter(userId);
    res.json({ message: "Đã cộng 10 EXP", data: result });
};

module.exports = { getAllReaderExp, getReaderExpById, addExpToReader };

const Wallet = require('../../../models/momo/walletUserModel');

// Tạo ví cho người dùng mới
const createWallet = async (userId) => {
    try {
      // Kiểm tra ví đã tồn tại chưa
      const existingWallet = await Wallet.findOne({ userId });
      if (existingWallet) {
        throw new Error('Wallet already exists');
      }
  
      const wallet = new Wallet({ userId });
      await wallet.save();
      return wallet;
    } catch (error) {
      throw error;
    }
  };

// Lấy thông tin ví của người dùng
const getWalletByUserId = async (userId) => {
  try {
    const wallet = await Wallet.findOne({ userId });
    if (!wallet) {
      throw new Error('Wallet not found');
    }
    return wallet;
  } catch (error) {
    throw error;
  }
};

// Cập nhật số dư ví
const updateWalletBalance = async (userId, amount) => {
  try {
    const wallet = await Wallet.findOne({ userId });
    if (!wallet) {
      throw new Error('Wallet not found');
    }

    wallet.balance += amount;  // Cập nhật số dư ví
    wallet.updatedAt = Date.now();
    await wallet.save();
    return wallet.balance;  // Trả về số dư ví mới
  } catch (error) {
    throw error;
  }
};

module.exports = {
  createWallet,
  getWalletByUserId,
  updateWalletBalance,
};

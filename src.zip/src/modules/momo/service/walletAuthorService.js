// services/walletAuthor.service.js
const WalletAuthor = require('../../../models/momo/walletAuthorModel');

const getMonthKey = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
};

const createWallet = async (userId) => {
  const existing = await WalletAuthor.findOne({ userId });
  if (existing) return existing;

  const newWallet = new WalletAuthor({ userId });
  return await newWallet.save();
};

const getWalletByUserId = async (userId) => {
  return await WalletAuthor.findOne({ userId }).populate('userId', 'fullname username avatar');
};

const updateRevenue = async (userId, amount) => {
  const wallet = await WalletAuthor.findOne({ userId });
  if (!wallet) throw new Error('Wallet not found');

  const monthKey = getMonthKey();
  const current = wallet.monthlyRevenue.get(monthKey) || 0;

  wallet.monthlyRevenue.set(monthKey, current + amount);
  wallet.totalRevenue += amount;
  wallet.lastUpdated = new Date();

  return await wallet.save();
};

module.exports = {
  createWallet,
  getWalletByUserId,
  updateRevenue
};

const PurchaseHistory = require('../../../models/momo/purchaseHistoryModel');

exports.createPurchaseHistory = async (data) => {
  return await PurchaseHistory.create(data);
};

exports.getUserPurchases = async (userId) => {
  return await PurchaseHistory.find({ idUser: userId })
    .populate('idUser', 'fullname avatar')
    .populate('idNovel', 'title')
    .populate('idChapter', 'title order');
};

exports.hasPurchasedChapter = async (userId, chapterId) => {
  return await PurchaseHistory.exists({ idUser: userId, idChapter: chapterId });
};

exports.getPurchaseByUserAndChapter = async (userId, chapterId) => {
  return await PurchaseHistory.findOne({ idUser: userId, idChapter: chapterId });
};

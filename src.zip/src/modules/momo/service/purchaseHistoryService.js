const PurchaseHistory = require('../../../models/momo/purchaseHistoryModel');

exports.createPurchaseHistory = async (data) => {
  return await PurchaseHistory.create(data);
};

exports.getUserPurchases = async (userId) => {
  return await PurchaseHistory.find({ idUser: userId })
};
exports.hasPurchasedChapter = async (userId, chapterId) => {
  return await PurchaseHistory.findOne({ idUser: userId, idChapter: chapterId });
};

exports.getPurchaseByUserAndChapter = async (userId, chapterId) => {
  return await PurchaseHistory.findOne({ idUser: userId, idChapter: chapterId })
};
// lấy thống kê doanh thu của tiểu thuyết
exports.getNovelRevenueStats = async (novelId) => {
  const purchases = await PurchaseHistory.find({ idNovel: novelId })
    .populate('idUser', 'fullname')           // populate user mua
    .populate('idChapter', 'title order')           // populate chapter
    .populate('idNovel', 'title');                  // giữ lại

    const validPurchases = purchases.filter(p => p.idChapter);

  const totalCoins = purchases.reduce((sum, purchase) => sum + (purchase.price || 0), 0);
  const totalChapters = new Set(purchases.map(p => p.idChapter?._id?.toString())).size;
  const purchaseCount = purchases.length;

  const chapterStats = purchases.reduce((acc, curr) => {
    const chapterId = curr.idChapter?._id?.toString();
    if (chapterId) {
      acc[chapterId] = (acc[chapterId] || 0) + 1;
    }
    return acc;
  }, {});

  return {
    purchases,
    totalCoins,
    totalChapters,
    purchaseCount,
    chapterStats
  };
};

exports.deleteByUser = async (userId) => {
  return await PurchaseHistory.deleteMany({ idUser: userId });
};

exports.deleteByChapter = async (chapterId) => {
  return await PurchaseHistory.deleteMany({ idChapter: chapterId });
};


// routes/walletAuthor.route.js
const express = require('express');
const router = express.Router();
const walletController = require('../controller/walletAuthorController');

// POST /api/wallet-author
router.post('/', walletController.createWallet);

// GET /api/wallet-author/:userId
router.get('/:userId', walletController.getWallet);

// PATCH /api/wallet-author/:userId/revenue
router.patch('/:userId/revenue', walletController.updateRevenue);

module.exports = router;

const walletService = require('../service/walletAuthorService');

const createWallet = async (req, res) => {
  try {
    const { userId } = req.body;
    const wallet = await walletService.createWallet(userId);
    res.status(201).json(wallet);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getWallet = async (req, res) => {
  try {
    const { userId } = req.params;
    const wallet = await walletService.getWalletByUserId(userId);
    if (!wallet) return res.status(404).json({ message: 'Wallet not found' });
    res.json(wallet);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const updateRevenue = async (req, res) => {
  try {
    const { userId } = req.params;
    const { amount } = req.body;
    const updated = await walletService.updateRevenue(userId, amount);
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  createWallet,
  getWallet,
  updateRevenue
};

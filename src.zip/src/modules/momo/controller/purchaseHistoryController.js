const purchaseService = require('..//service/purchaseHistoryService');

exports.create = async (req, res) => {
  try {
    const newPurchase = await purchaseService.createPurchaseHistory(req.body);
    res.status(201).json(newPurchase);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getUserPurchases = async (req, res) => {
  try {
    const purchases = await purchaseService.getUserPurchases(req.params.userId);
    res.status(200).json(purchases);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.checkPurchased = async (req, res) => {
  try {
    const { userId, chapterId } = req.query;
    const isPurchased = await purchaseService.hasPurchasedChapter(userId, chapterId);
    res.status(200).json({ isPurchased: !!isPurchased });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getNovelStats = async (req, res) => {
  try {
    const { novelId } = req.params;

    const stats = await purchaseService.getNovelRevenueStats(novelId);
    res.status(200).json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Xóa lịch sử mua của user
exports.deleteByUser = async (req, res) => {
  const { userId } = req.params;
  try {
    const result = await PurchaseHistoryService.deleteByUser(userId);
    return res.status(200).json({
      message: `Đã xóa ${result.deletedCount} lịch sử mua của user ${userId}`,
    });
  } catch (error) {
    console.error('Lỗi khi xóa purchase history theo user:', error);
    return res.status(500).json({ message: 'Lỗi server' });
  }
};

// Xóa lịch sử mua của chapter
exports.deleteByChapter = async (req, res) => {
  const { chapterId } = req.params;
  try {
    const result = await PurchaseHistoryService.deleteByChapter(chapterId);
    return res.status(200).json({
      message: `Đã xóa ${result.deletedCount} lịch sử mua của chapter ${chapterId}`,
    });
  } catch (error) {
    console.error('Lỗi khi xóa purchase history theo chapter:', error);
    return res.status(500).json({ message: 'Lỗi server' });
  }
};



const Chapter = require("../../../models/novels/chapterModel");
const ChapterContent = require("../../../models/novels/chapterContentModel");
const Novel = require("../../../models/novels/novelModel");

const addChapter = async (data) => {
    const { idNovel, title, role, price, imageUrl, content } = data;
  
    if (!content || content.trim() === "") {
      throw new Error("Nội dung chương là bắt buộc!");
    }
  
    // Kiểm tra xem idNovel có hợp lệ và tồn tại trong database không
    const novelExists = await Novel.findById(idNovel);
    if (!novelExists) {
      throw new Error("Tiểu thuyết không tồn tại!");
    }
  
    // Kiểm tra xem Novel đã có chương nào chưa, nếu có lấy order tiếp theo, nếu chưa thì order = 1
    const latestChapter = await Chapter.findOne({ idNovel }).sort({ order: -1 }); // Lấy chương có order cao nhất
    const order = latestChapter ? latestChapter.order + 1 : 1; // Nếu có chương thì order = order tiếp theo, nếu không thì order = 1
  
    // Tạo Chapter
    const chapter = new Chapter({
      idNovel,
      title,
      order,
      role,
      price,
      imageUrl,
    });
  
    // Lưu chương vào database
    const savedChapter = await chapter.save();
  
    // Tạo ChapterContent
    const chapterContent = new ChapterContent({
      idChapter: savedChapter._id,
      content,
    });
  
    // Lưu nội dung chương vào database
    await chapterContent.save();
  
    return { chapter: savedChapter, content: chapterContent.content };
  };
  
  

/**
 * Lấy danh sách tất cả Chapters có cùng Novel
 */
const getChapters = async () => {
    try {
        return await Chapter.find();
    } catch (error) {
        throw new Error(error.message);
    }
};

/**
 * Lấy Chapter theo ID
 */
const getChapterById = async (id) => {
    try {
        const chapter = await Chapter.findById(id);
        if (!chapter) {
            throw new Error("Không tìm thấy chapter.");
        }
        return chapter;
    } catch (error) {
        throw new Error(error.message);
    }
};

/**
 * Cập nhật Chapter theo ID
 */
const updateChapterById = async (id, updateData) => {
    try {
        const updatedChapter = await Chapter.findByIdAndUpdate(id, updateData, { new: true });
        if (!updatedChapter) {
            throw new Error("Không tìm thấy chapter để cập nhật.");
        }
        return updatedChapter;
    } catch (error) {
        throw new Error(error.message);
    }
};

/**
 * Xóa Chapter theo ID
 */
const deleteChapterById = async (id) => {
    try {
        const deletedChapter = await Chapter.findByIdAndDelete(id);
        if (!deletedChapter) {
            throw new Error("Không tìm thấy chapter để xóa.");
        }
        return deletedChapter;
    } catch (error) {
        throw new Error(error.message);
    }
};

module.exports = { addChapter, getChapters, getChapterById, updateChapterById, deleteChapterById };
